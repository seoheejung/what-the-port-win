# 사용 가이드

[README로 돌아가기](../README.md)

## 언어 선택

기본 한국어. **설정 → 언어 / Language → 한국어 또는 English → 설정 저장**. 재시작 없이 적용 및 다음 실행에 유지. 영어 화면에서는 **Settings → Language → Save preferences**.

## 실행했는데 창이 보이지 않을 때

- **WhatThePort.exe:** 트레이 앱 본체. 더블클릭으로 실행하는 파일.
- **wtp.exe:** PowerShell·터미널용 명령 도구. `wtp list`·`wtp link` 지원. 인수 없이 실행 시 같은 폴더의 `WhatThePort.exe` 호출.

- **기존 앱 실행 중:** 다른 폴더의 EXE도 실행 중인 앱의 창 열기로 연결. 새 버전으로 교체할 때는 기존 트레이 → 앱 종료 / Quit 후 새 EXE 실행.
- **저장된 위치:** 재실행 시 저장한 모니터·위치에서 표시. `Ctrl+Alt+P` 또는 트레이 아이콘으로 표시·숨김. 설정 → 창 위치 초기화로 주 모니터 복귀.
- **실행 직후 표시:** EXE 직접 실행·재실행 시 첫 마우스·키보드 조작 전까지 자동 숨김 보류. 이후 기존 자동 숨김 적용. ×·Esc로 즉시 숨김 가능.
- **포터블 구성:** ZIP의 모두 압축 풀기 후 EXE·Core DLL·설정 파일·fonts 폴더를 함께 유지.
- **여러 파일이 있는 이유:** DLL·설정·fonts는 앱의 구성 요소이고, README·docs·LICENSE는 안내·라이선스. 각 파일이 별도 앱으로 상주하는 것은 아님. ZIP의 README에 파일별 용도 안내.
- **SmartScreen:** 다운로드 파일의 평판 확인에 따른 실행 전 경고. 앱 창 표시 문제와 별개이며 멀웨어 확정 판정이나 안전 보증을 의미하지 않음. 보호 기능 해제 없이 출처·검사 결과 확인 필요. [Microsoft 안내](https://learn.microsoft.com/en-us/windows/apps/package-and-deploy/smartscreen-reputation).

## 선택할 수 없는 항목과 일부 종료

- **보호됨 · 종료 불가:** 이 앱·상위 실행 프로세스 또는 터미널·에이전트·시스템·DB·컨테이너 보호. 비활성 체크박스는 정상 동작. 상태·체크박스 도움말에 보호 사유 제공.
- **보호 앱:** wmux, cagent, Docker 등. 해당 앱의 종료 기능 사용.
- **일부 종료:** 서버 본체 종료 성공 후 하위 프로세스 종료 실패 가능. 포트가 닫히면 목록에서 제거. **종료 결과 상세**에서 프로세스별 오류·보호 제외 내역 확인.
- **본체 종료 실패:** 하위 프로세스 종료도 중단. 성공·실패를 되돌릴 수 있는 원자적 작업이 아님.

## 프로젝트와 세션 연결

서버 상세 → **Link session & preview** → 폴더·에이전트·세션 ID·미리보기 주소 입력 → **Save links**.

| 항목 | 기준 |
|---|---|
| 프로젝트 폴더 | 서버가 실행된 실제 폴더 |
| 에이전트 | Codex / Claude Code |
| 세션 ID | 로컬 CLI에서 재개 가능한 실제 세션 ID |
| 미리보기 | `https://….vercel.app` 형식의 등록 주소 |
| 연결 키 | 프로젝트 폴더 + 포트; 다른 프로젝트의 포트 재사용 시 이전 링크 승계 방지 |

상세의 **Session: Codex** 표시는 부모 프로세스 기준 연관 정보. 정확한 세션 연결 완료 여부와 별개이며, 재개에는 세션 ID 등록 필요.

재개 전제: 선택한 에이전트 CLI 설치·로그인, 해당 CLI에서 접근 가능한 세션. 데스크톱 전용 세션의 CLI 재개 가능 여부는 사용 도구의 지원 범위에 따라 별도 확인 필요.

### CLI 링크 등록

```powershell
.\dist\wtp.exe link --port 3000 --folder C:\dev\my-app --agent codex --session YOUR_SESSION_ID
.\dist\wtp.exe link --port 5173 --folder C:\dev\other-app --agent claude --session YOUR_SESSION_ID --preview https://my-preview.vercel.app
```

`wtp link` 실행 시 해당 폴더·포트의 링크 레코드 교체. 세션과 미리보기 동시 유지 시 같은 명령에 두 항목 모두 입력.

Vercel API 인증·배포 없음. 등록된 HTTPS 주소의 브라우저 열기만 지원. PowerShell·Windows Terminal 외의 사용자 지정 터미널 명령 미지원.

## 패널 위치

제목을 드래그하면 위치 자동 저장. 숨김·트레이 재열기·앱 재실행 후 복원. Ctrl+Shift+방향키로 키보드 이동. 저장 위치가 없으면 첫 실행은 주 모니터, 트레이 클릭은 해당 모니터 기준. 모니터 연결 해제 시 보이는 작업 영역으로 보정.

초기화: 설정 → **창 위치 초기화**. 핀(◇/◆)은 포커스를 잃었을 때 창 유지 여부이며, 위치 저장과 별개.

## 단축키

| 키 | 동작 |
|---|---|
| Ctrl+Alt+P | 트레이 패널 표시·숨김 |
| Esc | 목록 복귀 / 패널 숨김 |
| Ctrl+, | 설정 |
| Ctrl+Shift+방향키 | 패널 이동·위치 저장 |
| 차트의 ← / → / Home / End | 이전·다음·첫·마지막 표본 |
| Tab / ↑ / ↓ / Enter | 컨트롤·서버 선택 / 상세 열기 |
| C | 목록에서 정리 화면 |
| O | 상세에서 로컬 URL 열기 |
| T | 상세에서 프로젝트 터미널 열기 |
| A | 상세에서 등록된 에이전트 세션 재개 |
| V | 상세에서 등록된 Vercel 미리보기 열기 |

전역 단축키 충돌 시 트레이 아이콘으로 패널 열기. 창의 ×는 숨김, 트레이 우클릭 → **앱 종료 / Quit**은 앱 종료.

## 설정

### 앱 자체의 CPU·메모리

화면의 RAM·CPU는 감시 대상 서버의 사용량. 앱 자체의 사용량은 Windows 작업 관리자에서 `WhatThePort.exe` 확인. 기본 3초마다 조회하며 숨김 상태에서는 화면을 다시 그리지 않음. 서버별 이력은 최근 10분·최대 601개 표본으로 제한.

트레이로 시작하면 처음 열 때까지 패널 생성을 미룸. 창을 숨기면 목록·차트 컨트롤을 비우고 30초 뒤 창을 해제하며, 다시 열 때 최신 데이터·선택·핀 상태를 복원. 저장하지 않은 설정·프로젝트 링크 입력은 유지. WPF와 글꼴 캐시는 남을 수 있어 처음 시작할 때의 RAM 사용량으로 완전히 돌아가지는 않음. [실측 결과](resource-usage.md).

샘플 주기를 늘리면 조회 횟수와 상태·경고 반영 빈도가 함께 감소. ×·Esc는 창만 숨기므로 감시는 계속됨. 감시를 끝내려면 트레이 우클릭 → **앱 종료 / Quit**.

소스에서 재측정: `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/measure-resources.ps1`. Windows 작업 표시줄이 있는 데스크톱에서 실행. 격리된 설정·자동 정리 Off·기본 3초 주기로 실제 조회를 수행하며, 숨김·표시·다시 숨김을 각각 30초 측정. `-FixtureServers 5`를 추가하면 측정용 루프백 서버 다섯 개를 띄워 감시하며 해당 프로세스만 정리. 결과는 `artifacts/resource-usage.json`; CPU는 전체 논리 코어 대비 비율, RAM은 working set. 서버 수·환경에 따라 달라지며 장시간 누수 검증은 아님.

### 설정 기본값

| 항목 | 기본값·동작 |
|---|---|
| 샘플 주기 | 3초; 설정 범위 1–30초 |
| 메모리 경고 | 2 GB |
| 증가량 경고 | 500 MB / 10분; 0은 끄기 |
| CPU 경고 | 전체 논리 코어 대비 80%, 연속 3회 |
| 자동 정리 | Off / Ask / Automatic; 기본 Off |
| idle 기준 | 4시간; 연결 없음·CPU 2% 미만의 연속 관측 |
| 터미널 | PowerShell / Windows Terminal |
| 전체 리스너 | 사용자 정의 실행 파일·일반 앱의 TCP 리스너 포함 |

보호·경고 서버의 자동 정리 제외. 조회 실패·오래된 스냅샷의 자동 정리 중단. 실시간 요청 로그를 읽지 않는 표본 기반 idle 판정.

설정 저장 위치: `%LOCALAPPDATA%\WhatThePort\settings.json`.
프로젝트 링크 위치: 같은 폴더의 `links.json`.
손상된 설정: 자동 정리가 꺼진 기본값 복구 및 화면 안내. 수동 JSON 수정 후 앱 재실행 필요.

## 설치·업데이트·제거

```powershell
# 시작 메뉴 등록
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/install.ps1
# 로그인 시 자동 시작 등록
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/install.ps1 -StartWithWindows
```

| 작업 | 방법 |
|---|---|
| 설치 위치 | `%LOCALAPPDATA%\Programs\WhatThePort` |
| PATH | 변경 없음 |
| 업데이트 | 트레이 → Quit 후 새 빌드·폴더 교체·재설치 |
| 제거 | 앱 종료 후 설치 폴더 및 시작 메뉴·시작프로그램의 `What the Port.lnk` 삭제 |
| 설정 보존 | `%LOCALAPPDATA%\WhatThePort` 폴더 유지 |

미서명 로컬 빌드. 코드 서명·자동 업데이트·온라인 배포 없음.

## 측정·종료 관련 참고

- **CPU** — 전체 논리 코어 대비 비율; 프로세스별 코어 사용률과 차이 가능
- **메모리** — resident working set; 공유 페이지 중복 및 실제 회수량 차이 가능
- **프로젝트 폴더** — 접근 가능한 x64/WOW64 프로세스의 현재 폴더 조회; 실패 시 프로세스 이름 표시
- **에이전트 식별** — 이름 변경·중간 셸에 따른 연관 식별 실패 가능
- **프로세스 종료** — 선택 트리의 즉시 종료; 저장·정리 훅 보장 없음
- **자동 재시작 서버** — 상위 npm 감시 프로세스가 재시작한 경우 원래 터미널에서 중지 필요
- **알림** — Windows 알림 설정·집중 지원에 따른 배너 미표시 가능
